	<?php
	class FME_CWMP_Genreal_Settings_View {
		public function __construct() {

			$this->general_settings_output();	
		}	

		
		public function general_settings_output() {

			$cwmp_gs_array=get_option('fme_cwmp_general_settings');
			if (isset($cwmp_gs_array['pop_btn_txt'] ) ) {
				$pop_btn_text=$cwmp_gs_array['pop_btn_txt'];	
			} else {
				$pop_btn_text='';
			}
			
			$btn_text='';
			if (!empty($pop_btn_text) ) {
				$btn_text=$pop_btn_text;
			}

			?>
	<div id="message" hidden class="fme_cwmp_save updated inline"><p><strong> <?php echo esc_html__('Your settings have been saved.', 'audio-player-for-woocommerce'); ?></strong></p></div>
	<h2><?php echo esc_html__('Audio Player Settings', 'audio-player-for-woocommerce'); ?> </h2>
	<table class="form-table">

		<tbody>
			<tr valign="top" class="">
				<th scope="row" class="titledesc"><?php echo esc_html__('Display on shop page', 'audio-player-for-woocommerce'); ?></th>
				<td class="">
					<fieldset>
						<legend class="screen-reader-text"><span><?php echo esc_html__('Display on shop page', 'audio-player-for-woocommerce'); ?></span></legend>
						<label for="cmp_shop">
							<input name="cmp_shop" id="cmp_shop_chk" <?php echo filter_var($cwmp_gs_array['chk_shop']); ?> type="checkbox" value="checked" class=""><?php echo esc_html__('To display audio player on shop page.', 'audio-player-for-woocommerce'); ?> 
						</label> 
					</fieldset>
				</td>
			</tr>
			<tr valign="top" class="">
				<th scope="row" class="titledesc"><?php echo esc_html__('Add Custom Text for Pop-up Button', 'audio-player-for-woocommerce'); ?></th>
				<td class="">
					<fieldset>
						<legend class="screen-reader-text"><span><?php echo esc_html__('Add Custom Text for Pop-up Button', 'audio-player-for-woocommerce'); ?></span></legend>
						<label for="cmp_shop">
							<input name="cmp_shop_btn_txt_chk_box" id="cmp_shop_btn_txt_chk" <?php echo filter_var($cwmp_gs_array['btn_txt_chk']); ?> type="checkbox" value="checked" class=""><?php echo esc_html__('Adds custom text for pop up button shown on shop page.', 'audio-player-for-woocommerce'); ?><br><br><input type="text"  class="fme_pop_btn_txt_input" name="fme_pop_btn_txt_input" style="width: 60%;" hiddden value="<?php echo filter_var($btn_text); ?> " >
						</label> 
					</fieldset>
				</td>
			</tr>
			
			<tr valign="top" class="">
				<th scope="row" class="titledesc"><?php echo esc_html__('Display on single product page', 'audio-player-for-woocommerce'); ?></th>
				<td class="forminp forminp-checkbox">
					<fieldset>
						<legend class="screen-reader-text"><span><?php echo esc_html__('Display on single product page', 'audio-player-for-woocommerce'); ?></span></legend>
						<label for="cmp_single_product_page">
							<input name="cmp_single_product_page" id="cmp_single_product_chk" type="checkbox" class="" <?php echo filter_var($cwmp_gs_array['chk_single']); ?> type="checkbox" value="checked" class="" ><?php echo esc_html__('To display audio player on single product page.', 'audio-player-for-woocommerce'); ?> 
						</label>
					</fieldset>
				</td>
			</tr>
			
			<tr valign="top" >
				<th scope="row" class="titledesc">
					<label for="player_bg_color"><?php echo esc_html__('Player Theme Color', 'audio-player-for-woocommerce'); ?><span class="woocommerce-help-tip" data-tip="<?php echo esc_html__('This sets the progress color of audio played.', ''); ?>"></span></label>
				</th>
				<td class="forminp forminp-color">‎
					<input  id="cmp_theme_color" value="<?php echo filter_var ($cwmp_gs_array['theme_clr']); ?>" class="jscolor" >
				</td>			
				</tr>
			<tr valign="top">
				<th scope="row" class="titledesc">
					<label for="cmp_bar_color"><?php echo esc_html__('Progrss bar Color', 'audio-player-for-woocommerce'); ?> <span class="woocommerce-help-tip" data-tip="<?php echo esc_html__('This sets color of progress bar before playing audio.', ''); ?>"></span></label>
				</th>
				<td class="forminp forminp-color">‎
					<input class="jscolor" id="cmp_empty_bar_color" value="<?php echo filter_var ($cwmp_gs_array['empty_bar_clr']); ?>">
				</td>
			</tr>

			<tr valign="top">
				<th scope="row" class="titledesc">
					<label for="cmp_progress"><?php echo esc_html__('Fill bar color', 'audio-player-for-woocommerce'); ?> <span class="woocommerce-help-tip" data-tip="<?php echo esc_html__('This sets the progress color of audio played.', ''); ?>"></span></label>
				</th>
				<td class="forminp forminp-color">‎
					<input class="jscolor" id="cmp_fill_bar_color" value="<?php echo filter_var ($cwmp_gs_array['fill_bar_clr']); ?>" >
				</td>	
			</tr>
			
			<tr valign="top" >
				<th scope="row" class="titledesc">
					<label for="player_bg_color"><?php echo esc_html__('Player Buttons Color', 'audio-player-for-woocommerce'); ?><span class="woocommerce-help-tip" data-tip="<?php echo esc_html__('This sets the control buttons color.', ''); ?>"></span></label>
				</th>
				<td class="forminp forminp-color">‎
					<input class="jscolor" id="cmp_button_color" value="<?php echo filter_var ($cwmp_gs_array['player_btn_clr']); ?>" >
				</td>			
			</tr> 
			<tr valign="top" >
				<th scope="row" class="titledesc">
					<label for="player_bg_color"><?php echo esc_html__('Player Buttons Hover Color', 'audio-player-for-woocommerce'); ?><span class="woocommerce-help-tip" data-tip="<?php echo esc_html__('This sets the control buttons color on hover.', ''); ?>"></span></label>
				</th>
				<td class="forminp forminp-color">‎
					<input class="jscolor" id="cmp_button_hover_color" value="<?php echo filter_var ($cwmp_gs_array['player_btn_hover_clr']); ?>" >
				</td>			
			</tr>
			<tr valign="top" >
				<th scope="row" class="titledesc">
					<label for="player_bg_color"><?php echo esc_html__('Text Color on Audio Player', 'audio-player-for-woocommerce'); ?><span class="woocommerce-help-tip" data-tip="<?php echo esc_html__('This sets the color of text shown on audio player.', ''); ?>"></span></label>
				</th>
				<td class="forminp forminp-color">‎
					<input class="jscolor" id="cmp_music_text_color" value="<?php echo filter_var ($cwmp_gs_array['txt_music_clr']); ?>">
				</td>			
			</tr>
			<tr valign="top" >
				<th scope="row" class="titledesc">
					<label for="player_bg_color"><?php echo esc_html__('List Button Color', 'audio-player-for-woocommerce'); ?><span class="woocommerce-help-tip" data-tip="<?php echo esc_html__('This sets the color of list button.', ''); ?>"></span></label>
				</th>
				<td class="forminp forminp-color">‎
					<input class="jscolor" id="cmp_list_btn_color" value="<?php echo filter_var ($cwmp_gs_array['list_btn_clr']); ?>">
				</td>			
			</tr>				
			<tr valign="top" >
				<th scope="row" class="titledesc">
					<label for="player_bg_color"><?php echo esc_html__('List Header Text Color', 'audio-player-for-woocommerce'); ?><span class="woocommerce-help-tip" data-tip="<?php echo esc_html__('This sets the color of header text of list.', ''); ?>"></span></label>
				</th>
				<td class="forminp forminp-color">‎
					<input class="jscolor" id="cmp_list_header_color" value="<?php echo filter_var ($cwmp_gs_array['list_header_clr']); ?>">
				</td>			
			</tr>
			<tr valign="top" >
				<th scope="row" class="titledesc">
					<label for="player_bg_color"><?php echo esc_html__('List Background Color', 'audio-player-for-woocommerce'); ?><span class="woocommerce-help-tip" data-tip="<?php echo esc_html__('This sets the color of list background.', ''); ?>"></span></label>
				</th>
				<td class="forminp forminp-color">‎
					<input class="jscolor" id="cmp_list_bg_color" value="<?php echo filter_var ($cwmp_gs_array['list_bg_clr']); ?>">
				</td>			
			</tr>

			<tr valign="top" >
				<th scope="row" class="titledesc">
					<label for="player_bg_color"><?php echo esc_html__('List Text Color', 'audio-player-for-woocommerce'); ?> <span class="woocommerce-help-tip" data-tip="<?php echo esc_html__('This sets the color of text of list items.', ''); ?>"></span></label>
				</th>
				<td class="forminp forminp-color">‎
					<input class="jscolor" id="cmp_list_text_color" value="<?php echo filter_var ($cwmp_gs_array['list_txt_clr']); ?>">
				</td>			
			</tr>

		</tbody>
	</table>
			<?php
		}
	}

	new FME_CWMP_Genreal_Settings_View();
	
