jQuery(document).ready(function(){


  /*****************list button click function********************************/
  jQuery(".fme_list_btn").click( function(){ 
    if(!jQuery(this).parent().hasClass("active")) {
      var h1=jQuery(".fme_modal").height();
      var top= 135 - h1;
      jQuery(this).css("top",top);
    } else {
      jQuery(this).css("top","-50px");
    }
    jQuery(this).parent().toggleClass("active");

    jQuery(".fme-music-lists").toggleClass("active")
  });


  var audio_list=[];
  let beatpack = [{}];
  var  dir_url=jQuery("#myModal").attr("pluginurl");
  var song = new Audio();
  var CurrentSong = 1;
  let mp_gs=[];
  var theme_clr, empty_bar, fill_bar_clr, player_btn_clr, player_btn_hover_clr, txt_music_clr, list_btn_clr, list_header_clr, list_bg_clr, list_txt_clr;
  var id=jQuery("#mysingleModal").attr("postid");


  /********************Ajax on load sets the player settings according to user****************/
  jQuery.ajax({
    method:'POST',
    url:myAjax.ajaxurl,
    data: { action:'fme_cwmp_audio_array', id:id 

  }, 

  success: function(r){

    mp_gs=r.musicplayergs;

    theme_clr='#'+mp_gs["theme_clr"];
    empty_bar='#'+mp_gs["empty_bar_clr"];
    fill_bar_clr='#'+mp_gs["fill_bar_clr"];
    player_btn_clr='#'+mp_gs["player_btn_clr"];
    player_btn_hover_clr='#'+mp_gs["player_btn_hover_clr"];
    txt_music_clr='#'+mp_gs["txt_music_clr"];
    list_btn_clr='#'+ mp_gs["list_btn_clr"];
    list_header_clr='#'+mp_gs["list_header_clr"];
    list_bg_clr='#'+mp_gs["list_bg_clr"];
    list_txt_clr='#'+mp_gs["list_txt_clr"]; 

    jQuery(".fme-stop-btn").html(stopsvg);
    jQuery(".fme-play-pause").html(playsvg);
    jQuery(".fme-prev-btn").html(prevsvg);
    jQuery(".fme-next-btn").html(nextsvg);
    jQuery(".fme-volume-btn").html(volumesvg);

    jQuery(".fme_music_box").css("background-color",theme_clr);
    jQuery(".fme-music-label").css("background-color",theme_clr);
    jQuery(".fme_progress_bar").css("background-color",empty_bar);
    jQuery(".fillBar").css("background-color",fill_bar_clr)
    jQuery(".fme_list_btn").css("background-color",list_btn_clr);
    jQuery(".fme-music-time").css("color",txt_music_clr);
    jQuery(".fme-song-name").css("color",txt_music_clr);
    jQuery(".fme-music-label").css("color",list_header_clr);
    jQuery(".fme_ul_list_item").css("color",list_txt_clr);
    jQuery(".fme_ul_list_item").css("background-color",list_bg_clr)

    /*****************Players button color on load********************/
    jQuery(".fmesvgbtn").css("fill",player_btn_clr);
    /*****Play Pause Circle svg****/
    jQuery(".fmecircle").css("stroke",player_btn_clr);

    jQuery(".fmesvgbtn").css("filter","drop-shadow(2px 4px 6px black)");

    /****************************************************************************/
    if(r.data!="") {
      newitem="";
              // mp_gs=r.musicplayergs;
              jQuery.each(r.data,function(key,value){

                beatpack.push({
                  "name":value[0],
                  "artist":value[0],
                  "src":value[1],
                  "thumbnail":value[2] })

                load(1,beatpack);

              })


              for (i=1; i<beatpack.length; i++) {
                arr=beatpack[i]
                name=arr['name'];
                newsong= new Audio();
                newsong.src=arr['src'];
                val=newsong.src;
                newsong.pause();
                time=newsong.duration;
                  // alert(time);
                if (name.length>16){
                  
                  name=name.substring(0, 16)+"...";

                }  
                  newitem+='<li class="fme-list-li-item" val="'+i+'">'+i+") "+'<span class="fme-music-span">'+name+'</span><em class="fme-music-em">...</em></li>';
                }

                jQuery('.fme_ul_list_item').html(newitem); 
              }
              
            } 

          });
  /*****************************on load ajax ends**********************************/




  playsvg=`<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="40px"
  height="40px" viewBox="0 0 39.61 39.61" style="enable-background:new 0 0 39.61 39.61;" xml:space="preserve">
  <style type="text/css">
  .playbtnst0{fill:none;stroke:`+player_btn_clr+`;stroke-width:2.2019;stroke-miterlimit:10;}
  .playbtnst1{fill:`+player_btn_clr+`;}
  </style>
  <defs>
  </defs>
  <circle class="playbtnst0 fmecircle" cx="19.8" cy="19.8" r="18.7"/>
  <path class="playbtnst1 fmebtn" d="M30.26,19.97c0,0.52-0.29,0.99-0.76,1.23l-13.78,6.89c-0.19,0.1-0.4,0.15-0.62,0.15c-0.26,0-0.51-0.07-0.73-0.21
  c-0.4-0.25-0.65-0.7-0.65-1.17V13.08c0-0.76,0.62-1.38,1.38-1.37c0.21,0,0.42,0.05,0.62,0.15l13.78,6.89
  C29.97,18.98,30.26,19.45,30.26,19.97z"/>
  </svg>`;

  pausesvg=`<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="39.67px"
  height="39.67px" viewBox="0 0 39.67 39.67" style="enable-background:new 0 0 39.67 39.67;" xml:space="preserve">
  <style type="text/css">
  .pausebtnst0{fill:none;stroke:`+player_btn_clr+`;stroke-width:2.2059;stroke-miterlimit:10;}
  .pausebtnst1{fill-rule:evenodd;clip-rule:evenodd;fill:`+player_btn_clr+`;}
  </style>
  <defs>
  </defs>
  <circle class="pausebtnst0 fmecircle" cx="19.84" cy="19.84" r="18.73"/>
  <path id="pause_1_" class="pausebtnst1 fmebtn" d="M14.24,10.98c-0.61,0-1.1,0.57-1.1,1.26v13.91c0,0.7,0.49,1.27,1.1,1.27h2
  c0.61,0,1.1-0.57,1.1-1.27V12.24c0-0.7-0.49-1.26-1.1-1.26H14.24z M23.26,10.98c-0.61,0-1.1,0.57-1.1,1.26v13.91
  c0,0.7,0.49,1.27,1.1,1.27h2.01c0.61,0,1.1-0.57,1.1-1.27V12.24c0-0.7-0.49-1.26-1.1-1.26H23.26z"/>
  </svg>`;

  prevsvg=`<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="40px"
  height="40px" viewBox="0 0 40 40" style="enable-background:new 0 0 40 40;" xml:space="preserve">
  <style type="text/css">
  .prevbtnst0{fill:none;stroke:#000000;stroke-width:1.000000e-04;stroke-miterlimit:10;}
  .prevbtnst1{fill:#010101;}
  </style>
  <defs>
  </defs>
  <path class="prevbtnst0 fmebtn" d="M40,40H0V0h40V40z"/>
  <path class="prevbtnst01 fmebtn" d="M15.35,26.33V12.47c0-0.73-0.58-1.35-1.35-1.35c-0.77,0-1.39,0.62-1.39,1.39v13.82c0,0.77,0.58,1.39,1.35,1.39
  C14.7,27.72,15.35,27.13,15.35,26.33z M26.4,26.37V12.51c0-1.19-1.38-1.81-2.27-0.99l-8.31,6.89c-0.33,0.28-0.49,0.67-0.49,1.07
  c0,0.39,0.16,0.79,0.49,1.07l8.31,6.89C25.02,28.17,26.4,27.55,26.4,26.37z"/>
  </svg>`;

  nextsvg=`<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="40px"
  height="40px" viewBox="0 0 40 40" style="enable-background:new 0 0 40 40;" xml:space="preserve">
  <style type="text/css">
  .nextbtnst0{fill:none;stroke:#000000;stroke-width:1.000000e-04;stroke-miterlimit:10;}
  .nextbtnst1{fill:#010101;}
  </style>
  <defs>
  </defs>
  <path class="nextbtnst0 fmebtn" d="M40,40H0V0h40V40z"/>
  <path class="nextbtnst01 fmebtn" d="M25.05,27.72c0.77,0,1.35-0.62,1.35-1.39V12.51c0-0.77-0.62-1.39-1.39-1.39c-0.77,0-1.35,0.62-1.35,1.35v13.85
  C23.67,27.13,24.33,27.72,25.05,27.72z M14.9,27.43l8.31-6.89c0.33-0.28,0.49-0.67,0.49-1.07c0-0.39-0.16-0.79-0.49-1.07l-8.31-6.89
  c-0.89-0.82-2.27-0.19-2.27,0.99v13.85C12.62,27.55,14,28.17,14.9,27.43z"/>
  </svg>`;

  stopsvg=`<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="40px"
  height="40px" viewBox="0 0 40 40" style="enable-background:new 0 0 40 40;" xml:space="preserve">
  <style type="text/css">
  .stopst0{fill:none;stroke:#000000;stroke-width:1.000000e-04;stroke-miterlimit:10;}
  .stopst1{fill:#00000;}
  </style>
  <defs>
  </defs>
  <path class="stopst0 fmebtn" d="M40,40H0V0h40V40z"/>
  <path class="stopst1 fmebtn" d="M14.93,11.87h10.15c1.35,0,2.44,1.09,2.44,2.44v10.15c0,1.35-1.09,2.44-2.44,2.44H14.93
  c-1.35,0-2.44-1.09-2.44-2.44V14.31C12.5,12.96,13.59,11.87,14.93,11.87z"/>
  </svg>`;

  volumesvg=`<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="40px"
  height="40px" viewBox="0 0 40 40" style="enable-background:new 0 0 40 40;" xml:space="preserve">
  <style type="text/css">
  .volumest0{fill:none;stroke:#000000;stroke-width:1.000000e-04;stroke-miterlimit:10;}
  .volumest1{fill:#010101;}
  </style>
  <defs>
  </defs>
  <path class="volumest0 fmebtn" d="M40,40H0V0h40V40z"/>
  <g>
  <path class="st1" d="M11.9,14.6c-0.65,0.37-1.48,0.65-2.23,0.65H8.1c-0.56,0-0.93,0.46-0.93,1.02v6.03c0,0.56,0.37,1.02,0.93,1.02
  h1.58c0.83,0,1.58,0.19,2.23,0.65l5.94,3.52c0.65,0.37,1.39-0.09,1.39-0.83V11.91c0-0.74-0.74-1.21-1.39-0.83L11.9,14.6z"/>
  <path class="st1" d="M21.08,22.02c-0.19,0-0.37-0.09-0.46-0.19c-0.28-0.28-0.28-0.74,0-1.02c0.46-0.46,0.65-1.02,0.65-1.58
  c0-0.56-0.28-1.21-0.65-1.58c-0.28-0.28-0.28-0.74,0-1.02s0.74-0.28,1.02,0c0.74,0.65,1.11,1.58,1.11,2.6s-0.37,1.85-1.11,2.6
  C21.45,21.93,21.27,22.02,21.08,22.02z M23.86,25.08c-0.19,0-0.46-0.09-0.56-0.19c-0.37-0.28-0.46-0.83-0.09-1.21
  c2.41-2.6,2.41-6.4,0-8.9c-0.37-0.37-0.28-0.83,0.09-1.21c0.37-0.28,1.02-0.28,1.3,0.09c2.97,3.25,2.97,7.88,0,11.13
  C24.42,24.99,24.14,25.08,23.86,25.08z M27.85,27.58c-0.19,0-0.37,0-0.56-0.19c-0.46-0.28-0.56-0.74-0.28-1.11
  c3.15-4.27,3.15-9.83,0-14.1c-0.28-0.37-0.19-0.93,0.28-1.11c0.46-0.28,1.02-0.19,1.3,0.19c3.62,4.82,3.62,11.13,0,15.95
  C28.41,27.49,28.13,27.58,27.85,27.58z"/>
  </g>
  </svg>`;

  mutesvg=`<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="40px"
  height="40px" viewBox="0 0 40 40" style="enable-background:new 0 0 40 40;" xml:space="preserve">
  <style type="text/css">
  .mutest0{fill:none;stroke:#00000;stroke-width:1.000000e-04;stroke-miterlimit:10;}
  .mutest1{fill-rule:evenodd;clip-rule:evenodd;fill:#01000;}
  </style>
  <defs>
  </defs>
  <path class="mutest0" d="M40,40H0V0h40V40z"/>
  <g>
  <path class="mutest1" d="M16.05,14.02h-5.6c-0.54,0-0.98,0.44-0.98,0.98v8.81c0,0.54,0.44,0.98,0.98,0.98h5.61l4.66,2.8
  c0.3,0.18,0.68,0.19,0.99,0.01c0.31-0.17,0.5-0.5,0.5-0.85V12.06c0-0.35-0.19-0.68-0.5-0.85c-0.31-0.17-0.68-0.17-0.99,0.01
  L16.05,14.02z"/>
  <path class="st1" d="M28.99,19.89l1.73-1.73c0.38-0.38,0.38-1,0-1.38s-1-0.38-1.38,0L27.6,18.5l-1.73-1.73
  c-0.38-0.38-1-0.38-1.38,0s-0.38,1,0,1.38l1.73,1.73l-1.73,1.73c-0.38,0.38-0.38,1,0,1.38s1,0.38,1.38,0l1.73-1.73L29.34,23
  c0.38,0.38,1,0.38,1.38,0s0.38-1,0-1.38L28.99,19.89z"/>
  </g>
  </svg>`;



  /****************Pop up muisc player modal on click to listen audio button****************************/
  jQuery('.openmodal').click(function(e){
    playerdeafult();
    e.preventDefault();
    beatpack = [{}];
    var id=jQuery(this).attr("id");
    newitem='';
    /*************Pop up music player and load audio ajax*********/
    jQuery.ajax({
      method:'POST',
      url:myAjax.ajaxurl,
      data: { action:'fme_cwmp_audio_array', id:id 

    },
    success: function(r){

      newitem="";
              // mp_gs=r.musicplayergs;
              jQuery.each(r.data,function(key,value){

                beatpack.push({
                  "name":value[0],
                  "artist":value[0],
                  "src":value[1],
                  "thumbnail":value[2] })

                load(1,beatpack);

              })

              for (i=1; i<beatpack.length; i++) {
                arr=beatpack[i]
                name=arr['name'];
                newsong= new Audio();
                newsong.src=arr['src'];
                val=newsong.src;
                newsong.pause();
                time=newsong.duration;

                if (name.length>16){
                  
                  name=name.substring(0, 16)+"...";

                }  
                  newitem+='<li class="fme-list-li-item" val="'+i+'">'+i+") "+'<span class="fme-music-span">'+name+'</span><em class="fme-music-em">...</em></li>';
                  
                }

                jQuery('.fme-play-pause').html(playsvg);
                jQuery('.fme_ul_list_item').html(newitem);
                jQuery(".fmesvgbtn").css("fill",player_btn_clr);
                jQuery(".fmecircle").css("stroke",player_btn_clr);



              }


            });
    /****************Ajax end *******/
    // }
    /************display modal****************/
    var modal=jQuery(this).parents('.audio_div').find('.fme_modal');
    modal.css("display","block");

  })
  /*******************modal button click end***********/


  jQuery('.fme_modal').click(function(e){
    e.preventDefault();
  })


  var url=jQuery(".fme_player").attr("pluginurl");
  playurl=url+'/assets/images/play.svg';
  pauseurl=url+'/assets/images/pause.svg';
  var playing = false,
  artistname = jQuery(".artist-name"),
  musicName = jQuery(".fme_music_box").find(".fme-song-name").find("span"),
  time = jQuery(".fme-music-time"),
  fillBar = jQuery(".fillBar");
  thumbnail=jQuery(".fme-music-thumbnail");
  
  
  /*********audio load function on load music player****/
  function load(CurrentSong,beatpack) {

    artistname.html(beatpack[CurrentSong].name);
    musicName.html(beatpack[CurrentSong].artist);
    song.src = beatpack[CurrentSong].src;
    thumbnail.attr("src", beatpack[CurrentSong].thumbnail);
    

  }

  function playSong() {
    // songname();
    artistname.html(beatpack[CurrentSong].name);
    musicName.html(beatpack[CurrentSong].artist);
    song.src = beatpack[CurrentSong].src;

    thumbnail.attr("src", beatpack[CurrentSong].thumbnail);
    song.play();
    song.volume=jQuery(".vertical-slider").val()/100;

    jQuery('.fme-play-pause').html(pausesvg);
    
    jQuery(".fmesvgbtn").css("fill",player_btn_clr);
    /*****Play Pause Circle svg****/
    jQuery(".fmecircle").css("stroke",player_btn_clr);


    /***********For playing text in list********/
    jQuery(".fme-list-li-item").find("em").text("...");
    jQuery.each(jQuery(".fme-list-li-item"),function(index,element){
      if ( jQuery(element).attr("val")==CurrentSong) {
        jQuery(element).find("em").text("Now Playing");
      }

    })

  }

  /**********update audio time************/

  function songtime() {
    var position = ( song.currentTime / song.duration) * 100;
    var current = song.currentTime;
    var duration = song.duration;
    if (isNaN(duration)){
        if(song.paused==true){
        song.muted=true; 
        song.play();
        setTimeout(function(){
        song.pause();
        song.muted=false;  
        },50);
        duration = song.duration;
      } else{
        duration=0;
      }
    }
  
    var durationMinute = Math.floor(duration / 60);
    var durationSecond = Math.floor(duration - durationMinute * 60);
    if ( durationSecond < 10 ) {
       durationSecond="0"+ durationSecond;
    }
    var durationLabel = durationMinute + ":" + durationSecond;
    currentSecond = Math.floor(current);
    currentMinute = Math.floor(currentSecond / 60);
    currentSecond = currentSecond - currentMinute * 60;
    

    if (currentSecond < 10) {
      currentSecond = "0" + currentSecond;
    }
    var currentLabel = currentMinute + ":" + currentSecond;
    var indicatorLabel = currentLabel + " / " + durationLabel;

    fillBar.css("width", position + "%");

    jQuery(".fme-music-time").html(indicatorLabel);
  }

  song.addEventListener("timeupdate", function () {
    songtime();
   
  });


  jQuery(".fme-play-pause").click(function playOrPause() {
       jQuery(".fmesvgbtn").css("fill",player_btn_clr);
      jQuery(".fmecircle").css("stroke",player_btn_clr);
   
    if (song.paused) {
      song.play();
      playing = true;
      jQuery(this).html(pausesvg);


      jQuery.each(jQuery(".fme-list-li-item"),function(index,element){
        if ( jQuery(element).attr("val")==CurrentSong) {
          jQuery(element).find("em").text("Now Playing");
        }
        
      })

    } else {
      song.pause();
      playing = false;
      // jQuery(this).attr("src",playurl);
      jQuery(".fme-list-li-item").find("em").text("...");
      jQuery(this).html(playsvg);
    }

  });
  song.onended=function(){
    jQuery('.fme-list-li-item').find("em").text("...");
    jQuery(".fme-play-pause").html(playsvg);
    jQuery(".fmesvgbtn").css("fill",player_btn_clr);
    jQuery(".fmecircle").css("stroke",player_btn_clr);
	CurrentSong++;
    if (CurrentSong == beatpack.length) {
      CurrentSong = 1;
	  artistname.html(beatpack[CurrentSong].name);
      musicName.html(beatpack[CurrentSong].artist);
      song.src = beatpack[CurrentSong].src;
      thumbnail.attr("src", beatpack[CurrentSong].thumbnail);		
		return;
    }
    playSong();
  }

/*******previous song******/
  function prev() {
    CurrentSong--;
    if (CurrentSong < 1) {
      CurrentSong = beatpack.length - 1;
    }
    playSong();

    jQuery('.fillBar').width("0%");
	
  }
/*******next song******/  
  function next() {   
    CurrentSong++;
    if (CurrentSong == beatpack.length) {
      CurrentSong = 1;
    }
    playSong();
  }
/*******stop audio******/
  function stop()
  {
    if (song!="") {
    song.src = beatpack[CurrentSong].src;
    song.currentTime=0;
    song.pause();
    jQuery(".fme-play-pause").html(playsvg);
    jQuery(".fmesvgbtn").css("fill",player_btn_clr);
    jQuery(".fmecircle").css("stroke",player_btn_clr);

    fillBar.css("width", "0%");
    }
  }

/*******close pop up modal******/
  jQuery('.fme_close').click(function(e){
    e.preventDefault();
    song.pause();
    jQuery(".fillBar").css("width","0%"); 
    jQuery(this).parents('.audio_div').find('.fme_modal').css("display","none");
  })
  

  jQuery("body").on("mouseover",".fmesvgbtn", function(){

    jQuery(this).css("fill",player_btn_hover_clr);
    jQuery(this).find(".fmecircle").css("stroke",player_btn_hover_clr);
  })

  jQuery("body").on("mouseleave",".fmesvgbtn",function(){

    jQuery(this).css("fill",player_btn_clr)
    jQuery(this).find(".fmecircle").css("stroke",player_btn_clr);
  })

  jQuery("body").on("click",".fmesvgbtn", function(){

    jQuery(this).css("fill",player_btn_hover_clr);
    jQuery(this).find(".fmecircle").css("stroke",player_btn_hover_clr);

    setTimeout(function(){ 
      jQuery(".fmesvgbtn").css("fill",player_btn_clr);
      jQuery(".fme-play-pause").css("fill",player_btn_clr);
      /*****Play Pause Circle svg****/
      jQuery(".fmecircle").css("stroke",player_btn_clr);

    }, 250);  
  })
  
  jQuery(".fme-next-btn").click(function(e){
    e.preventDefault();
    next();
  });
  jQuery(".fme-prev-btn").click(function(e){
    e.preventDefault();
    prev();
  });
  jQuery(".fme-stop-btn").click(function(e){
    e.preventDefault();
    stop();
    e.preventDefault();
    
  })

  jQuery('.fme_close').click(function(e){
    e.preventDefault();
    stop();
  })
  jQuery("body").on("click",".fme_progress_bar",function(e) {    

    var progbar = jQuery(this);
        var pos = e.pageX - progbar.offset().left; //Position cursor
        var percent = pos / progbar.width(); //Get width element
        var fillpercent=percent*100;
        song.currentTime = percent * song.duration;

      })


  jQuery("body").on("click",".fme-list-li-item",function(){
    cs=jQuery(this).attr("val");
    CurrentSong=cs;
    playSong();

  });

  /***********Mute btn click************/

  jQuery(".fme-volume-btn").click(function() {
    
    jQuery(this).parents(".fme-action-button").find(".vertical-slider").toggleClass("vertical-slider-active");


  })
  
  jQuery(".vertical-slider").on("input", function(){
    value=jQuery(this).val()/100;
    if (value==0) {
      songmute();
    } else {
      songunmute();
    }
    song.volume=value;
  })

  /*deafult css of palyer when click on load*/
  function playerdeafult() {
    jQuery(".fillBar").css("width","0%");
    jQuery(".fme_modal").css("display","none");
    jQuery(".fme_modal").find(".fme_music_box").removeClass(".active");
    jQuery(".fme-music-lists").removeClass("active");
    jQuery(".fme_list_btn").parent().removeClass("active");
    jQuery(".fme_list_btn").css("top","-50px")


    }


    function songmute(){
      song.muted=true;
      jQuery(".fme-volume-btn").html(mutesvg);
      
      setTimeout(function(){ 
        jQuery(".fmesvgbtn").css("fill",player_btn_clr);
        /*****Play Pause Circle svg****/
        jQuery(".fmecircle").css("stroke",player_btn_clr);

      }, 250);
    }

    function songunmute() {
      song.muted=false;
      jQuery(".fme-volume-btn").html(volumesvg); 
      setTimeout(function(){ 
        jQuery(".fmesvgbtn").css("fill",player_btn_clr);
        /*****Play Pause Circle svg****/
        jQuery(".fmecircle").css("stroke",player_btn_clr);

      }, 250);
    }

    /*************windows resize height modal to adjust css*******/
    var h0= jQuery(".fme_modal").height();

    jQuery(window).resize(function(){
     var h1=jQuery(".fme_modal").height();
  
     var top= 135 - h1;

   if(jQuery(".fme-music-list").hasClass("active")) {
    jQuery(".fme_list_btn ").css("top",top+"px");
    }

  })

    /***************To stop audio on change image slider*********/
    jQuery("body").on("click",".flex-control-thumbs", function() {
      flexview=jQuery(this).parents(".woocommerce-product-gallery").find(".flex-viewport");
      figure=flexview.find("figure");
       div=figure.find("div");
      if (song!="" && div.hasClass("flex-active-slide") && div.hasClass("fme_single_modal"))
      {
        stop();
       }
    })


    /***********single page div width on window resize***/
    width=jQuery(".woocommerce-product-gallery").width();
    jQuery("#mysingleModal").css("width",width);
    
    jQuery(window).resize(function() {
      width=jQuery(".woocommerce-product-gallery").width();
      jQuery("#mysingleModal").css("width",width);
    })

})
