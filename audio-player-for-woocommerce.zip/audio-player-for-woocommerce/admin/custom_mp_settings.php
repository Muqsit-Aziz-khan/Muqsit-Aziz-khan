<?php
class FME_CWMP_WC_Settings_NEW_Tab {

	public function  __construct() {

		 add_action('admin_enqueue_scripts', array($this, 'fme_cwmp_admin_scripts'), 10, 0);
		add_filter( 'woocommerce_settings_tabs_array', array($this, 'fme_cmp_add_settings_tab'), 50, 1 );
		add_action( 'woocommerce_settings_tabs_fme_cmp_settings_tab', array($this,'fme_cmp_settings_tab'), 10, 0 );
		
		add_action('wp_ajax_fme_cwmp_gs_array', array($this, 'fme_music_player_gs'));

		add_action('wp_ajax_fme_cwmp_audio_array', array($this, 'fme_cwmp_audio_array'));
		add_action('wp_ajax_nopriv_fme_cwmp_audio_array', array($this, 'fme_cwmp_audio_array'));

	}

	
	public  function fme_cmp_add_settings_tab( $settings_tabs ) {

		$settings_tabs['fme_cmp_settings_tab'] = __( 'Audio Player Settings', 'audio-player-for-woocommerce' );
		return $settings_tabs;
	}

	public  function fme_cmp_settings_tab() {


		require_once('view/music_tab_settings.php');
		?>
		<br>
		<br>
		<button name="save" class="button-primary" id="cwmp_gs_save_btn" type="submit" value="Save changes"><?php echo esc_html__('Save changes', 'audio-player-for-woocommerce'); ?></button>
		<?php
	}

	public  function fme_cwmp_admin_scripts() { 
		
		if ( is_admin() && ( ( isset($_GET['tab'] ) &&  'fme_cmp_settings_tab' == $_GET['tab'] ) || isset($_GET['action'])  && 'edit' === $_GET['action'] ) ) {

			if ( ( isset($_GET['action'])  && 'edit' === $_GET['action'] ) ) {
				wp_register_script('cwmp_admin_settings', plugin_dir_url(__FILE__) . 'assets/js/add_file.js', array('jquery'), 1.0);
				wp_enqueue_script('cwmp_admin_settings');
			}
			wp_enqueue_style( 'fme-cwmp-admin-settings-css', plugins_url( 'assets/css/product_menu.css', __FILE__ ), false , 1.0 );
		 
			wp_enqueue_script( 'fme-muisc-general-setting-js', plugins_url( '/assets/js/generalsettings.js', __FILE__ ), false, 1.0 );

			wp_localize_script('fme-muisc-general-setting-js', 'mygsAjax', array('ajaxurl'=>admin_url('admin-ajax.php')));
			
			wp_enqueue_script( 'jscolor-js', plugins_url( '/assets/js/jscolor.js', __FILE__ ), false, 1.0 );			
		}   
	}    




	/****************Save general settings****************/
	public function fme_music_player_gs() {
		if ( isset($_REQUEST['musicplayer_gs_array'] ) ) {
			$cwmp_gs_array=map_deep( wp_unslash( $_REQUEST['musicplayer_gs_array'] ), 'sanitize_text_field' );
		}
		

		update_option('fme_cwmp_general_settings', $cwmp_gs_array);
		die();	
	}


	/**********Function for frontend*******/
	public	function fme_cwmp_audio_array() {
		if ( isset( $_REQUEST['id'] ) ) {
			$post_id=map_deep( wp_unslash( $_REQUEST['id'] ), 'sanitize_text_field' );
		}

		$audio_array=array();
		$cwmp_front_gs_array=get_option('fme_cwmp_general_settings');

		$audio_post_meta= get_post_meta( $post_id, 'fme_audio_data' , $single = false );
		
		if (!empty($audio_post_meta) ) {
			$audio_array=$audio_post_meta[0];
		}
			
		$new_arr=array('data'=>$audio_array,'musicplayergs'=>$cwmp_front_gs_array);
	
		echo filter_var(wp_send_json( $new_arr));
		

		die();
	}

}	



new FME_CWMP_WC_Settings_NEW_Tab();


