jQuery(document).ready(function(){
	
	btn_txt_chk=jQuery('input[name="cmp_shop_btn_txt_chk_box"]:checked').val() || "off";
	
	jQuery('#cmp_shop_btn_txt_chk').click(function() {
	btn_txt_chk=jQuery('input[name="cmp_shop_btn_txt_chk_box"]:checked').val() || "off";
		if (btn_txt_chk=='checked') {
			jQuery(".fme_pop_btn_txt_input").removeAttr("hidden")
		} else{
			jQuery(".fme_pop_btn_txt_input").attr("hidden","")
		}
	})

	if (btn_txt_chk=='checked') {
			jQuery(".fme_pop_btn_txt_input").removeAttr("hidden")
		} else{
			jQuery(".fme_pop_btn_txt_input").attr("hidden","")
		}

	jQuery("#cwmp_gs_save_btn").click(function(e) {
		e.preventDefault();

		var chk_shop=jQuery('input[name="cmp_shop"]:checked').val() || "off";
		var chk_single=jQuery('input[name="cmp_single_product_page"]:checked').val() || "off";
		var btn_txt_chk=jQuery('input[name="cmp_shop_btn_txt_chk_box"]:checked').val() || "off";
		var pop_btn_txt=jQuery('.fme_pop_btn_txt_input').val();
		var theme_clr=jQuery('#cmp_theme_color').val();
		var empty_bar_clr=jQuery('#cmp_empty_bar_color').val();
		var fill_bar_clr=jQuery('#cmp_fill_bar_color').val();
		var player_btn_clr=jQuery('#cmp_button_color').val();
		var player_btn_hover_clr=jQuery('#cmp_button_hover_color').val();
		var txt_music_clr=jQuery('#cmp_music_text_color').val();
		var list_btn_clr=jQuery('#cmp_list_btn_color').val();
		var list_header_clr=jQuery('#cmp_list_header_color').val();
		var list_bg_clr=jQuery('#cmp_list_bg_color').val();
		var list_txt_clr=jQuery('#cmp_list_text_color').val();

		



		musicplayer_gs_array={ chk_shop:chk_shop,
							   chk_single:chk_single,
							   btn_txt_chk:btn_txt_chk,
							   pop_btn_txt:pop_btn_txt,
							   theme_clr:theme_clr,
							   empty_bar_clr:empty_bar_clr,
							   fill_bar_clr:fill_bar_clr,
							   player_btn_clr:player_btn_clr,
							   player_btn_hover_clr:player_btn_hover_clr,
							   txt_music_clr:txt_music_clr,
							   list_btn_clr:list_btn_clr,
							   list_header_clr:list_header_clr,
							   list_bg_clr:list_bg_clr,
							   list_txt_clr:list_txt_clr
							  };
			// console.log(musicplayer_gs_array);	
						  
		 jQuery.ajax({
    		method:'POST',
    		url:mygsAjax.ajaxurl,
    		data: { action:'fme_cwmp_gs_array', musicplayer_gs_array:musicplayer_gs_array 

    		},
   		 	success: function(r){	
   		 		  jQuery('.fme_cwmp_save').show();
   		 		  jQuery('html, body').animate({
   		 		  	scrollTop: jQuery("#wpbody-content").offset().top
   		 		  }, 1500);
   		 		  jQuery('.fme_cwmp_save').fadeOut(4000);
   		 		
    		}
		})	 

	})

})