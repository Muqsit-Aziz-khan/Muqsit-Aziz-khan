<?php

/*
 * Plugin Name: Audio Player for Woocommerce 
   Description: Engage users with audio streaming, boost revenue by selling audio files as downloadable products. 
   Author: FME Addons
   TextDomain: audio-player-for-woocommerce
   Version: 1.0.0
   Woo: 18734000034138:c3836ea74fe16d2a12597bd910a5622c
  
*/
 
if ( ! defined( 'WPINC' ) ) {

	die;

}

if ( !in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {

	function my_admin_notice() {

			// Deactivate the plugin
			deactivate_plugins(__FILE__);
			$error_message = __('This plugin requires <a href="http://wordpress.org/extend/plugins/woocommerce/">WooCommerce</a> plugin to be installed and active!', 'audio-player-for-woocommerce');
			die( filter_var($error_message) );
	}
	add_action( 'admin_notices', 'my_admin_notice' );

}

if ( !class_exists( 'Fme_CMWP_For_Woocommerce' ) ) {

	class Fme_CWMP_For_Woocommerce {
		
		public function __construct() {
			
			register_activation_hook( __FILE__, array($this, 'fme_plugindefault_activate' ) );

			if (is_admin()) {

				 require_once('admin/custom_mp_settings.php');
				 require_once('admin/custom_mp_product_tab.php');

			} else { 
				 require_once('frontend/frontend.php');
			}
		}	
		public function fme_plugindefault_activate() { 

			
			$cwmp_genral_settings=get_option('fme_cwmp_general_settings');	

			if (empty($cwmp_genral_settings)) {				
				$cwmp_genral_settings=array('chk_shop'=>'checked','btn_txt_chk'=>'off' , 'chk_single'=>'checked', 'theme_clr'=>'#2f364c', 'empty_bar_clr'=>'#6c6060', 'fill_bar_clr'=>'#88d52a', 'player_btn_clr'=>'#a32719', 'player_btn_hover_clr'=>'#ee5d5d', 'txt_music_clr'=>'#c2bcbc', 'list_btn_clr'=>'#c2bc0f', 'list_header_clr'=>'#d2b72d ', 'list_bg_clr'=>'#a6b3f2', 'list_txt_clr'=>'#0c0909' );
				update_option('fme_cwmp_general_settings', $cwmp_genral_settings);
			}
		}	
		
		

 
	}
	new Fme_CWMP_For_Woocommerce();
}


