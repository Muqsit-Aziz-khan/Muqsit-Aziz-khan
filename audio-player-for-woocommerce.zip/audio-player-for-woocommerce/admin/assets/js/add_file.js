jQuery(document).ready(function(){
	
/***************************************************/

// var default_cam_url=jQuery(".fme_hidden_values").attr("default_cam_url");
jQuery(".fme_new_row_data").removeAttr('hidden');

var new_file_row=jQuery(".fme_new_row_data")[0].outerHTML;
jQuery(".fme_new_row_data").attr('hidden','');
// console.log(new_file_row);	

	jQuery('.insert_cwmp_file').click(function(e){
		e.preventDefault();
		jQuery(this).parents('table').find('tbody').append(new_file_row);
		
	})


	jQuery('body').on('click','.cwmp_delete',function(e){
		e.preventDefault();

		jQuery(this).parents('tr').remove();
	})


/**********************audio file loader button****************************/

	jQuery('body').on('click','.cwmp_upload_file_button', function(e) {
		e.preventDefault();
		var curr = jQuery(this);

		var mediaUploader;
		mediaUploader = wp.media.frames.file_frame = wp.media({
			button: {
				text: 'Choose Audio'
			}, multiple: false });
		mediaUploader.on('select', function() {
			var attachment = mediaUploader.state().get('selection').first().toJSON();
			
			if (attachment.type!='audio'){
				alert("Please Select Audio File");
				return;
			}
			curr.attr('src', attachment.url);
			curr.parents('tr').find('.cwmp_input_url').attr('value',attachment.url);


			
    // .attr('val',"abcd");
 	//   curr.parents('td').find('.remove_button').show();
     jQuery('.modal').css('overflow', 'scroll');
});

		mediaUploader.open();

	});
/**********************image file loader button****************************/

	jQuery('body').on('click','.cwmp_upload_img_file_button', function(e) {
		e.preventDefault();
		var curr = jQuery(this);

		var mediaUploader;
		mediaUploader = wp.media.frames.file_frame = wp.media({
			button: {
				text: 'Choose Image'
			}, multiple: false });
		mediaUploader.on('select', function() {
			var attachment = mediaUploader.state().get('selection').first().toJSON();
			
			if (attachment.type!='image'){
				alert("Please Select Image");
				return;
			}
			curr.attr('src', attachment.url);
			curr.parents('tr').find('input[name="fme_cwmp_field_option_image[]"]').attr("value",attachment.url);
			curr.parents('td').find('.fme_remove_atag').removeAttr("hidden");
			curr.parents('td').find('.fme_remove_atag').css("display","flex");
     jQuery('.modal').css('overflow', 'scroll');
});

		mediaUploader.open();

	});


/*******************Remove Image************************/

  jQuery(".fme_remove_atag").click(function(e){
  	var default_cam_url=jQuery(".fme_hidden_values").attr("default_cam_url");
  	jQuery(this).parents('td').find('img').attr('src',default_cam_url);
	jQuery(this).parents('td').find('input').attr('value',"");

	if(jQuery(this).parents('td').find('img').attr('src')==default_cam_url){
  	jQuery(this).attr("hidden","");
  	jQuery(this).css("display","none");
	}

  })

})