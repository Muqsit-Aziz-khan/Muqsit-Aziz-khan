<?php
class FME_CMS_Front_Main {
	public function __construct() {

		add_action('wp_enqueue_scripts' , array($this ,'fme_cms_front_scripts'), 10, 0);

		add_action('woocommerce_after_shop_loop_item_title', array($this, 'customize_shop_page_product_title'), 10, 0);
		
		$cwmp_single_front_gs_array=get_option('fme_cwmp_general_settings');
		
		$chk_single=$cwmp_single_front_gs_array['chk_single'];
		
		if ( !empty($chk_single) &&  'checked'==$chk_single ) {
			add_filter( 'woocommerce_single_product_image_thumbnail_html', array($this, 'fme_woocommerce_single_page_thumbnail'), 10, 2 );		
		}

		

	}

	public function fme_cms_front_scripts() {
		wp_enqueue_script('jquery');
		wp_enqueue_script( 'custom-audio-js', plugins_url( 'assets/js/audio_front.js', __FILE__ ), false, 1.0 );
		wp_enqueue_style( 'custom-audio-css', plugins_url( 'assets/css/audio.css', __FILE__ ), false, 1.0 );    
		wp_localize_script('custom-audio-js', 'myAjax', array('ajaxurl'=>admin_url('admin-ajax.php')));
	} 


	public function customize_shop_page_product_title() {

		$plugin_url= plugins_url( '', __FILE__);
		$terms = get_the_terms( get_the_ID(), 'product_cat' );
		$title = '';
		$post_id=get_the_ID();
		$audio_post_meta= get_post_meta( $post_id, 'fme_audio_data' , $single = false );	
		$cwmp_single_front_gs_array=get_option('fme_cwmp_general_settings');
		$audio_post_meta= get_post_meta( $post_id, 'fme_audio_data' , $single = false );
		$chk_single=$cwmp_single_front_gs_array['chk_shop'];		
		$custom_txt_chk=$cwmp_single_front_gs_array['btn_txt_chk'];
		if (isset($cwmp_single_front_gs_array['pop_btn_txt'] ) ) {
			$pop_btn_text=$cwmp_single_front_gs_array['pop_btn_txt'];
		} else {
			$pop_btn_text='';
		}
		
		if (!empty($pop_btn_text) && 'checked'==$custom_txt_chk ) {
			$cwmp_btn_text=$pop_btn_text;
		} else {
			$cwmp_btn_text='Listen Audio Demo';
		}

		if (!empty($audio_post_meta) ) {
				$audio_array=$audio_post_meta[0];
			

			foreach ($terms as $term) {
				$title = $term->name;
			}

			if (!empty($audio_array) ) {

				echo '
				<div class="audio_div">
				<div id="myModal" pluginurl=' . esc_html__($plugin_url) . ' class="fme_modal" >
				<a class="fme_close">x</i></a>

				<div class="fme_music_box">
				<div class="fme-music-album">
				<img class="fme-music-thumbnail" src="https://images.unsplash.com/photo-1533475184589-ad2b25374b56?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1350&q=80">
				<div class="fme-music-infos">
				<div class="fme-song-name"><span>Flamingo</span></div>
				</div>
				</div>
				<div class="fme-music-dashboard">
				<div class="fme-music-list">
				<div class=" fme_list_btn"><span></span></div>
				</div>
				<div class="fme-music-player">
				<div class="fme-music-time"><small class="current">0:00</small> / <small class="duration">0:00</small></div>
				<div class="fme-music-time-rail">

				<div class="fme_progress_bar">
				<div class="fillBar"></div>
				</div>
				</div>
				</div>
				<div class="fme-action-button">
				<a class="fme-stop-btn fmesvgbtn"><i class="fa fa-stop"></i></a>        	
				<a class="fme-prev-btn fmesvgbtn"><i class="fa fa-step-backward"></i></a>
				<a class="fme-play-pause fmesvgbtn"><i class="fa fa-play"></i></a>
				<a class="fme-next-btn fmesvgbtn"><i class="fa fa-step-forward"></i></a>
				
				<a class="fme-volume-btn fmesvgbtn"><i class="fa fa-volume-up"></i></a>
				<span>
				<input type="range" class="fmesvgbtn vertical-slider" orient="vertical" min="0" max="100" value="50">
				</span>
				</div>
				</div>
				<div class="fme-music-lists">
				<div class="fme-music-label">' . esc_html__('Audio List', 'audio-player-for-woocommerce') . '</div>
				<ul class="fme_ul_list_item">

				</ul>
				</div>
				</div>

				</div>

				<button id="' . esc_html__($post_id) . '" class="openmodal" >' . filter_var($cwmp_btn_text) . '</button>
				</div>
				<br>
				';

			}	
		}
	}
	



	public function fme_woocommerce_single_page_thumbnail ( $html, $attachment_id) {
		global $product,$post;
		$plugin_url= plugins_url( '', __FILE__);
		$post_id=get_the_ID();
		$cwmp_single_front_gs_array=get_option('fme_cwmp_general_settings');
		$audio_post_meta= get_post_meta( $post_id, 'fme_audio_data' , $single = false );
		$thumb='';
		$chk_single=$cwmp_single_front_gs_array['chk_single'];

	
		if ( !empty($chk_single) &&  'checked'==$chk_single && !empty($audio_post_meta) ) {

		
				$audio_array=$audio_post_meta[0];
			if (empty($audio_array)) {
				return $html;
			}
			
			$thumb= $audio_array[0][2];

			$columns= apply_filters( 'woocommerce_product_thumbnails_columns', 4 );
			$post_thumbnail_id = $product->get_image_id();
			$wrapper_classes   = apply_filters(
			'woocommerce_single_product_image_gallery_classes',
			array(
			'woocommerce-product-gallery',
			'woocommerce-product-gallery--' . ( $post_thumbnail_id ? 'with-images' : 'without-images' ),
			'woocommerce-product-gallery--columns-' . absint( $columns ),
			'images',
			)
			);

			$featured_image = get_post_thumbnail_id( $post->ID );

			if ( $attachment_id == $featured_image ) {
		
				$html  = '<div data-thumb="' . $thumb . '" data-thumb-alt="" class="woocommerce-product-gallery__image flex-active-slide" style="width: 323.802px; margin-right: 0px; float: left; display: block; position: relative; overflow: ;">
				
				<figure>
				<figcaption></figcaption>	
				<div id="mysingleModal" postid="' . esc_html__($post_id) . '" pluginurl=' . esc_html__($plugin_url) . ' class="fme_single_modal" >
				<div class="fme_music_box"  style="border-radius:15px " pluginurl=' . esc_html__($plugin_url) . '>
				<div class="fme-music-album">
				<img class="fme-single-page-music-thumbnail fme-music-thumbnail">
				<div class="fme-music-infos">
				<div class="fme-song-name"><span>My Audio</span></div>
				</div>
				</div>
				<div class="fme-music-dashboard">
				<div class="fme-music-list">
				<div class=" fme_list_btn"><span></span></div>
				</div>
				<div class="fme-music-player">
				<div class="fme-music-time"><small class="current">0:00</small> / <small class="duration">0:00</small></div>
				<div class="fme-music-time-rail">

				<div class="fme_progress_bar">
				<div class="fillBar"></div>
				</div>
				</div>
				</div>
				<div class="fme-action-button">
				<label style="width:auto" class="fme-stop-btn fmesvgbtn"></label>        	
				<label style="width:auto" class="fme-prev-btn fmesvgbtn"></label>
				<label style="width:auto" class="fme-play-pause fmesvgbtn"></label>
				<label style="width:auto" class="fme-next-btn fmesvgbtn"></label>
				<label style="width:auto" class="fme-volume-btn fmesvgbtn"></label>
				<span>
				<input type="range" class="fmesvgbtn vertical-slider" orient="vertical" min="0" max="100" value="50">
				</span>
				</div>
				</div>
				<div class="fme-music-lists">
				<div class="fme-music-label">' . esc_html__('Audio List', 'audio-player-for-woocommerce') . '</div>
				<ul class="fme_ul_list_item">          
				</ul>
				</div>
				</div>

				</div>
		 </figure>
		 </div>';

	   
			}
			return $html;
			
		}
		return $html;
	}
}

 new FME_CMS_Front_Main();


