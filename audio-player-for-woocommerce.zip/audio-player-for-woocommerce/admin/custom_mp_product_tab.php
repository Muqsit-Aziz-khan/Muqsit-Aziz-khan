<?php
class FME_CWMP_Product_Menu {
	public function __construct() {
		add_filter( 'woocommerce_product_data_tabs', array($this, 'product_data_tabs_pluginmenu'), 10, 1);
		add_action( 'woocommerce_product_data_panels', array($this, 'product_data_panels_pluginmenu'), 10, 0);

		add_action('save_post', array($this, 'save_wcmp_post_meta'), 10, 0);


	}

	public function product_data_tabs_pluginmenu( $tabs ) {
		$tabs['product_menu'] = array(
			'label'  => esc_html__( 'Audio Player', 'audio-player-for-woocommerce' ),
			'target' => 'product_menu_options',
			'class'  => array( 'show_if_downloadable' ),
		);
		return $tabs;
	}

	public function product_data_panels_pluginmenu() {
		$pid= get_the_ID();
		$audio_meta_array=get_post_meta( $pid, 'fme_audio_data', $single = false );
		if (!empty($audio_meta_array)) {
			$saved_audio_data=$audio_meta_array[0];
		}
		$default_src=plugins_url( '/assets/images/camera_icon.png', __FILE__ );
		$val='';
		$src=$default_src;

		?>

		<div id="product_menu_options"  class="panel woocommerce_options_panel">
			<h2><?php echo esc_html__('Upload Demo File', 'audio-player-for-woocommerce'); ?> </h2>

			<div>
				<table class="widefat" pro_id="<?php echo esc_html__($pid); ?>">
					<thead>
						<tr>
							<input type="hidden" class="fme_hidden_values" default_cam_url="<?php echo esc_html__($default_src); ?>" name="fme_cwmp_prod_id" value="<?php echo esc_html__($pid); ?>">
							<th><?php echo esc_html__('Name', 'audio-player-for-woocommerce'); ?> <span class="woocommerce-help-tip"></span></th>
							<th colspan="2"><?php echo esc_html__('Audio File URL', 'audio-player-for-woocommerce'); ?> <span class="woocommerce-help-tip"></span></th>
							<th colspan="3"><?php echo esc_html__('Thumbnail', 'audio-player-for-woocommerce'); ?><span class="woocommerce-help-tip"></span></th>
						</tr>
					</thead>
					<tbody class="ui-sortable">

					<tr class="fme_new_row_data" hidden>
						<td class="">
							<input class="fme_cmp_add_file_input" type="text" placeholder="File name" name="fme_cwmp_wc_file_names[]">
						</td>
							
						<td class="">
							<input readonly class="fme_cmp_add_file_input cwmp_input_url" type="text"  placeholder="http://" name="fme_cwmp_wc_file_urls[]">
						</td>
							
						<td class="cwmp_file_url_choose" width="1%">
							<a href="#" class="button cwmp_upload_file_button" data-choose="Choose file" data-update="Insert file URL"><?php echo esc_html__('Choose File', 'audio-player-for-woocommerce'); ?></a>
						</td>
	

						<td class="">
							<img class="cwmp_upload_img_file_button" src="<?php echo ( esc_html( $default_src) ); ?>"  class="form-control form-control-sm name_list radio_option_images" />
							<a hidden class="fme_remove_atag"><?php echo esc_html__('Remove', 'audio-player-for-woocommerce'); ?> </a>            
							<input name="fme_cwmp_field_option_image[]" hidden value="<?php echo ( esc_html( $val) ); ?>" accept="image/png, image/jpeg" >   
						</td>
						<td width="1%">
							<a href="#" class="cwmp_delete"><?php echo esc_html__('Delete', 'audio-player-for-woocommerce'); ?>
							</a>
							</td>
					</tr>

						
					<?php 
					if (empty($saved_audio_data)) {
						?>
						<tr>
							<td class="">
								<input class="fme_cmp_add_file_input" type="text" placeholder="File name" name="fme_cwmp_wc_file_names[]">
							</td>
							
							<td class="">
								<input readonly class="fme_cmp_add_file_input cwmp_input_url" type="text"  placeholder="http://" name="fme_cwmp_wc_file_urls[]">
							</td>
							
							<td class="cwmp_file_url_choose" width="1%">
								<a href="#" class="button cwmp_upload_file_button" data-choose="Choose file" data-update="Insert file URL"><?php echo esc_html__('Choose File', 'audio-player-for-woocommerce'); ?></a>
							</td>							

							<td class="">
								<img class="cwmp_upload_img_file_button" src="<?php echo ( esc_html( $src) ); ?>"  class="form-control form-control-sm name_list radio_option_images" />
								<a hidden class="fme_remove_atag"><?php echo esc_html__('Remove', 'audio-player-for-woocommerce'); ?> </a>
										   
								<input name="fme_cwmp_field_option_image[]" hidden value="<?php echo ( esc_html( $val) ); ?>" accept="image/png, image/jpeg" >   
							</td>
							<td width="1%">
								<a hidd href="#" class="cwmp_delete"><?php echo esc_html__('Delete', 'audio-player-for-woocommerce'); ?>
								</a>
							</td>
						</tr>
					
						<?php
					} else {
						foreach ($saved_audio_data as $key=>$value) {
										

										echo'
										<tr>
										<td><input class="fme_cmp_add_file_input" type="text" placeholder="File name" name="fme_cwmp_wc_file_names[]"
										value="' . filter_var($value[0]) . '">

										</td>
										<td class="">
										<input class="fme_cmp_add_file_input cwmp_input_url" type="text"  placeholder="http://" name="fme_cwmp_wc_file_urls[]
										"value="' . filter_var($value[1]) . '">
										</td>
										<td class="cwmp_file_url_choose" width="1%">
										<a href="#" class="button cwmp_upload_file_button" data-choose="Choose file" data-update="Insert file URL">Choose file</a>
										</td>
										<td class="">
											<img class="cwmp_upload_img_file_button" src="' . filter_var($value[2]) . '" class="form-control form-control-sm name_list radio_option_images" />  
											<a class="fme_remove_atag">' . esc_html__('Remove', 'audio-player-for-woocommerce') . '</a>          
											<input name="fme_cwmp_field_option_image[]" hidden value="' . filter_var($value[2]) . '" accept="image/png, image/jpeg" >   
										</td>
										<td width="1%">

										<a href="#" class="cwmp_delete">Delete
										</a>
										</td>
										</tr>';
										
						}
					}

					?>
							
					</tbody>
					<tfoot>
						<tr>
							<th colspan="5">
								<a href="#" class="button insert_cwmp_file" data-row="

								"><?php echo esc_html__('Add a file', 'audio-player-for-woocommerce'); ?></a>
							</th>
						</tr>

					</tfoot>
				</table>
			</div>
		</div>

			<?php


	}
	public function save_wcmp_post_meta() {
		// die();
		if (isset($_SERVER['REQUEST_METHOD'] ) ) {

			if ( 'POST'==$_SERVER['REQUEST_METHOD'] ) {

				if (isset($_REQUEST['fme_cwmp_wc_file_names']) && isset($_REQUEST['fme_cwmp_prod_id']) && isset($_REQUEST['fme_cwmp_wc_file_urls']) && isset($_REQUEST['fme_cwmp_field_option_image'])  ) {
					$filename= map_deep( wp_unslash( $_REQUEST['fme_cwmp_wc_file_names'] ), 'sanitize_text_field' );
					$id= map_deep( wp_unslash( $_REQUEST['fme_cwmp_prod_id'] ), 'sanitize_text_field' );
					$fileurl=map_deep( wp_unslash( $_REQUEST['fme_cwmp_wc_file_urls'] ), 'sanitize_text_field' );			
					$audio_data_array=[];
					$filearray=[];
					$filethumbnail=map_deep( wp_unslash( $_REQUEST['fme_cwmp_field_option_image'] ), 'sanitize_text_field');
					/*To get user saved downloadable files*/
					$array_saved=array();
					$array_saved=get_post_meta( $id, '_downloadable_files');
					if (empty($array_saved)) {
						$array_saved[0]=array();	
					} 
					$new_file_arr=$array_saved[0];
					$found=false;
					foreach ($fileurl as $nkey=>$nvalue) {
						
						if (!empty($fileurl[$nkey]) ) {
							if ( empty($filethumbnail[$nkey]) ) {
							
								$filethumbnail[$nkey]=plugins_url( 'assets/images/default-audio-thumbnail.jpg', __FILE__);
							}
							
							array_push($audio_data_array, [ $filename[$nkey], $fileurl[$nkey], $filethumbnail[$nkey]]  );
							/**For each loop to check if file is already saved in downloadable products or not**/
							foreach ($new_file_arr as $ckey=>$checkarray) {

								$array_to_check=$new_file_arr[$ckey];

								
								if (in_array($filename[$nkey], $array_to_check) && in_array($fileurl[$nkey], $array_to_check)) {
									$found=true;
									break;	 
								} else {
									$found=false;
								}
								  
							}
							/* if file not found */
							if (false==$found) {
								$random=rand();
									$new_file_arr[$random]=array('id'=>$random, 'name'=>$filename[$nkey], 'file'=>$fileurl[$nkey]);
							}						
											
						}

					}
					
					$array_saved[0]=$new_file_arr;
					
					
					update_post_meta( $id, '_downloadable_files', $array_saved[0] );
					update_post_meta( $id, 'fme_audio_data', $audio_data_array );
					

				}
			}
		}
	}
			
		
}
new FME_CWMP_Product_Menu();

